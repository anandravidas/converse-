from django.apps import AppConfig


class PrivatechatConfig(AppConfig):
    name = 'privatechat'
