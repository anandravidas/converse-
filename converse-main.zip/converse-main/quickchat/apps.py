from django.apps import AppConfig


class QuickchatConfig(AppConfig):
    name = 'quickchat'
